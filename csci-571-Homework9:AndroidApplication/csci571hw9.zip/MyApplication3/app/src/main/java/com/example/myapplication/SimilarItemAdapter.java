package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.squareup.picasso.Picasso;

import java.util.List;


public class SimilarItemAdapter extends RecyclerView.Adapter<SimilarItemAdapter.SimilarItemViewHolder> {


    //this context we will use to inflate the layout
    private Context mCtx;

    //we are storing all the products in a list
    private List<SimilarItem> itemList;

    //getting the context and product list with constructor
    public SimilarItemAdapter(Context mCtx, List<SimilarItem> itemList) {
        this.mCtx = mCtx;
        this.itemList = itemList;
    }

    @Override
    public SimilarItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflating and returning our view holder
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.similar_tab, null);
        return new SimilarItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(SimilarItemViewHolder holder, int position) {
        //getting the product of the specified position
        SimilarItem item = itemList.get(position);

        //binding the data with the viewholder views

        if(item.getImage()!=""){
            Picasso.with(holder.imageView.getContext()).load(item.getImage()).into(holder.imageView);
        }
        else{
            Picasso.with(holder.imageView.getContext()).load(R.drawable.star_circle).into(holder.imageView);
        }
        holder.textViewTitle.setText(item.getTitle());
        holder.textViewShipping.setText(item.getShipping());
        holder.textViewDaysLeft.setText(item.getDaysLeft()+" Days");
        holder.textViewCost.setText(item.getPrice()+" USD");


    }


    @Override
    public int getItemCount() {
        return itemList.size();
    }


    class SimilarItemViewHolder extends RecyclerView.ViewHolder {

        TextView textViewTitle, textViewDaysLeft, textViewShipping,textViewCost;
        ImageView imageView;

        public SimilarItemViewHolder(View itemView) {
            super(itemView);

            LinearLayout card=(LinearLayout) itemView.findViewById(R.id.clickCard);
            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v){
                    int pos=getAdapterPosition();
                    String url=itemList.get(pos).getItemUrl();
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    mCtx.startActivity(browserIntent);
                }
            });

            imageView = itemView.findViewById(R.id.imageView);
            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            textViewShipping = itemView.findViewById(R.id.textViewShipping);
            textViewDaysLeft = itemView.findViewById(R.id.textViewDaysLeft);
            textViewCost = itemView.findViewById(R.id.textViewCost);
        }

    }
}

