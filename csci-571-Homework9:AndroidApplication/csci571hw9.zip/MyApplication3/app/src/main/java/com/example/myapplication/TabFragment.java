package com.example.myapplication;

import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class TabFragment extends Fragment {

    int position;
    private TextView textView;

    //calling variables
    DbAdapter db;
    SimpleCursorAdapter adapter;
    //the recyclerview
    RecyclerView recyclerView;

    public static Fragment getInstance(int position) {
        Bundle bundle = new Bundle();
        bundle.putInt("pos", position);
        TabFragment tabFragment = new TabFragment();
        tabFragment.setArguments(bundle);
        return tabFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        position = getArguments().getInt("pos");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = null;
        if(position==0){
            view=inflater.inflate(R.layout.fragment_tab, container, false);
            Spinner spinner = (Spinner) view.findViewById(R.id.category_spinner);
            ArrayAdapter<CharSequence> spinner_adapter = ArrayAdapter.createFromResource(this.getContext(),
                    R.array.categories, android.R.layout.simple_spinner_item);
            spinner_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(spinner_adapter);
            return view;
        }
        else {
            view=inflater.inflate(R.layout.wishlist_tab, container, false);
            recyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
            recyclerView.setHasFixedSize(true);
            recyclerView.setLayoutManager(new GridLayoutManager(view.getContext(), 2));
            recyclerView.setVisibility(View.VISIBLE);
            LinearLayout error=(LinearLayout) view.findViewById(R.id.error);
            error.setVisibility(View.GONE);
            TextView error_data=(TextView) view.findViewById(R.id.error_data);
            error_data.setText("No Wishes");
            error_data.setVisibility(View.GONE);
            db = new DbAdapter(view.getContext());
            db.open();
            Cursor row = db.fetchAllData();
            List<Product> wishtList = new ArrayList<Product>();
            float price=0;
            Boolean elements_in_wishlist=false;
            if (row.moveToFirst()) {
                do {
                    elements_in_wishlist=true;
                    wishtList.add(new Product(row.getString(0),row.getString(1),row.getString(2),row.getString(3),row.getString(4),row.getString(5),row.getString(6),R.mipmap.cart_remove));
                    price+=Math.round(Float.parseFloat(row.getString(6).substring(1)) * 100.0)/ 100.0;
                } while (row.moveToNext());
                view.setTag("wishlist");
                Global.wishView=view;
                Global.wishprice=Math.round(price * 100.0)/ 100.0;
                TextView text2=(TextView) view.findViewById(R.id.text2);
                text2.setText(String.valueOf(row.getCount()));
                TextView text4=(TextView) view.findViewById(R.id.text4);
                text4.setText("$"+Global.wishprice);
                ProductAdapter2 adapter = new ProductAdapter2(view.getContext(), wishtList);
                recyclerView.setAdapter(adapter);
            }
            if(!elements_in_wishlist){
                recyclerView.setVisibility(View.GONE);
                LinearLayout layout=(LinearLayout) view.findViewById(R.id.wishes);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 150);
                lp.setMargins(0, 540, 0, 0);
                layout.setLayoutParams(lp);
                error=(LinearLayout) view.findViewById(R.id.error);
                error.setVisibility(View.VISIBLE);
                error_data=(TextView) view.findViewById(R.id.error_data);
                error_data.setText("No Wishes");
                error_data.setVisibility(View.VISIBLE);
            }
            return view;
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }
}