package com.example.myapplication;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.Spinner;

import org.json.JSONObject;

import java.util.List;

public class Global {
    public static String jsonResponse;
    public static String jsonInitialResponse;
    public static String selectedItemId;
    public static String title;
    public static String url;
    public static String price;
    public static List<SimilarItem> defaultList;
    public static String spinner1;
    public static Spinner spinner2;
    public static JSONObject jsonObj;
    public static String zip;
    public static View wishView;
    public static double wishprice;
    public static ImageView imgView;
    public static List<Product>  list;
    public static String tag;
    public static int pos;
}
