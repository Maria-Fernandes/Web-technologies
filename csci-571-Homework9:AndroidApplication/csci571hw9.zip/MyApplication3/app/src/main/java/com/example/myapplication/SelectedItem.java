package com.example.myapplication;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.share.model.ShareHashtag;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.widget.ShareDialog;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;

public class SelectedItem extends AppCompatActivity {

    private Toolbar toolbar;
    private TabLayout tabLayout;
    private ViewPager viewPager;

    DbAdapter db;
    SimpleCursorAdapter adapter;
    private ProgressBar spinner;
    private TextView text_spinner;

    private int[] tabIcons = {
            R.mipmap.information_variant,
            R.mipmap.truck_delivery,
            R.mipmap.google,
            R.mipmap.equal
    };

    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        RequestQueue queue = Volley.newRequestQueue(this);
        Bundle receiveBundle = this.getIntent().getExtras();
        String id = receiveBundle.getString("id");
        String path="http://csci571-node.us-east-2.elasticbeanstalk.com/itemDetails?itemId="+id;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, path,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        generateView(response);
                        // Display the first 500 characters of the response string.

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("fail");
            }
        });
        queue.add(stringRequest);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (item.getItemId() == android.R.id.home) {
            if(Global.tag=="add"){
                Global.imgView.setImageResource(R.drawable.cart_plus);
                Global.list.get(Global.pos).setIcon(R.drawable.cart_plus);
            }
            else
            if(Global.tag=="remove"){
                Global.imgView.setImageResource(R.drawable.cart_remove);
                Global.list.get(Global.pos).setIcon(R.drawable.cart_remove);
            }
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    public void generateView(String response) {
        Global.jsonResponse=response;
        setContentView(R.layout.activity_selected_item);
        TextView text=(TextView) findViewById(R.id.toolbar_title);
        Bundle receiveBundle = this.getIntent().getExtras();
        String title = receiveBundle.getString("title");
        String icon = receiveBundle.getString("icon");
        if(icon.equals("add")){
            ImageView imageViewRemove= findViewById(R.id.icon_button_remove);
            imageViewRemove.setVisibility(View.INVISIBLE);
            ImageView imageView = (ImageView)findViewById(R.id.icon_button);
            imageView.setVisibility(View.VISIBLE);
        }
        else{
            ImageView imageViewRemove= findViewById(R.id.icon_button_remove);
            imageViewRemove.setVisibility(View.VISIBLE);
            ImageView imageView = (ImageView)findViewById(R.id.icon_button);
            imageView.setVisibility(View.INVISIBLE);
        }
        if(title.length()>=30)
        text.setText(title.substring(0,30)+"...");
        else{
            text.setText(title);
        }

        toolbar = (Toolbar) findViewById(R.id.toolbaritem);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        viewPager = (ViewPager) findViewById(R.id.viewpageritem);
        ViewPagerAdapterItem adapter = new ViewPagerAdapterItem(getSupportFragmentManager());
        viewPager.setAdapter(adapter);

        tabLayout = (TabLayout) findViewById(R.id.tabsitem);
        tabLayout.setupWithViewPager(viewPager);
        setupTabIcons();

    }
    private void setupTabIcons() {
        tabLayout.getTabAt(0).setIcon(tabIcons[0]);
        tabLayout.getTabAt(1).setIcon(tabIcons[1]);
        tabLayout.getTabAt(2).setIcon(tabIcons[2]);
        tabLayout.getTabAt(3).setIcon(tabIcons[3]);
    }

    public void callFacebookApi(View view){
        ShareHashtag shareHashTag = new ShareHashtag.Builder().setHashtag("#CSCI571Spring2019Ebay").build();
        ShareLinkContent shareLinkContent = new ShareLinkContent.Builder()
                .setShareHashtag(shareHashTag)
                .setQuote("Buy "+Global.title+" at "+Global.price+" USD from "+Global.url+" below")
                .setContentUrl(Uri.parse(Global.url))
                .build();
        ShareDialog.show(SelectedItem.this, shareLinkContent);

    }

    public void AddToWishList(View view){
        try {
            db = new DbAdapter(view.getContext());
            db.open();
            ImageView imageView=view.findViewById(R.id.icon_button);
            imageView.setVisibility(View.INVISIBLE);
            ViewGroup row = (ViewGroup) view.getParent();
            ImageView imageViewRemove = (ImageView) row.findViewById(R.id.icon_button_remove);
            imageViewRemove.setVisibility(View.VISIBLE);
            Global.tag="remove";
            db.insert(Global.jsonObj.getString("id"),Global.jsonObj.getString("image"),Global.jsonObj.getString("title"),Global.jsonObj.getString("zipcode"),Global.jsonObj.getString("shipping"),Global.jsonObj.getString("condition"),Global.jsonObj.getString("price"),R.drawable.cart_remove);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void RemoveFromWishList(View view){
        try {
            db = new DbAdapter(view.getContext());
            db.open();
            ImageView imageViewRemove=view.findViewById(R.id.icon_button_remove);
            imageViewRemove.setVisibility(View.INVISIBLE);
            ViewGroup row = (ViewGroup) view.getParent();
            ImageView imageView = (ImageView) row.findViewById(R.id.icon_button);
            imageView.setVisibility(View.VISIBLE);
            Global.tag="add";
            db.delete(Global.jsonObj.getString("id"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
