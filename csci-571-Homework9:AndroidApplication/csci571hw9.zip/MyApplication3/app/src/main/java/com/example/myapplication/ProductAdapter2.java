package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;


import com.squareup.picasso.Picasso;

import java.util.List;


public class ProductAdapter2 extends RecyclerView.Adapter<ProductAdapter2.ProductViewHolder> {


    //this context we will use to inflate the layout
    private Context mCtx;

    //we are storing all the products in a list
    private List<Product> productList;

    DbAdapter db;
    SimpleCursorAdapter adapter;

    //getting the context and product list with constructor
    public ProductAdapter2(Context mCtx, List<Product> productList) {
        this.mCtx = mCtx;
        this.productList = productList;
    }

    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflating and returning our view holder
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.layout_products, null);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ProductViewHolder holder, int position) {
        //getting the product of the specified position
        Product product = productList.get(position);

        //binding the data with the viewholder views
        Picasso.with(holder.imageView.getContext()).load(product.getImage()).into(holder.imageView);
        holder.viewShoppingCart.setImageDrawable(mCtx.getResources().getDrawable(product.getIcon()));
        holder.textViewTitle.setText(product.getTitle());
        holder.textViewZipcode.setText(product.getZipcode());
        holder.textViewShipping.setText(product.getShipping());
        holder.textViewCondition.setText(product.getCondition());
        holder.textViewPrice.setText(product.getPrice());


    }


    @Override
    public int getItemCount() {
        return productList.size();
    }


    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView textViewTitle, textViewZipcode, textViewShipping,textViewCondition, textViewPrice;
        ImageView imageView,viewShoppingCart,itemSelected,wishListClicked;

        public ProductViewHolder(View itemView) {
            super(itemView);

            itemSelected = (ImageView) itemView.findViewById(R.id.imageView);
            itemSelected.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v){
                    int pos=getAdapterPosition();
                    String id=productList.get(pos).getId();
                    String title=productList.get(pos).getTitle();
                    Global.selectedItemId=id;
                    Bundle sendBundle = new Bundle();
                    sendBundle.putString("id", id);
                    sendBundle.putString("title",title);
                    sendBundle.putString("icon","remove");

                    Intent intent = new Intent(mCtx, SelectedItem.class);
                    intent.putExtras(sendBundle);
                    mCtx.startActivity(intent);
                }
            });

            wishListClicked = (ImageView) itemView.findViewById(R.id.viewShoppingCart);
            wishListClicked.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v){
                    db = new DbAdapter(v.getContext());
                    db.open();
                    int pos=getAdapterPosition();
                    String id=productList.get(pos).getId();
                    db.delete(id);
                    Cursor row = db.fetchAllData();
                    TextView text2=(TextView) Global.wishView.findViewById(R.id.text2);
                    text2.setText(String.valueOf(row.getCount()));
                    TextView text4=(TextView) Global.wishView.findViewById(R.id.text4);
                    Global.wishprice=(Math.round(Global.wishprice * 100.0)/ 100.0)-(Math.round(Float.parseFloat(productList.get(pos).getPrice().substring(1)) * 100.0)/ 100.0);
                    text4.setText("$"+Global.wishprice);
                    Toast.makeText(v.getContext(),productList.get(pos).getTitle()+" was removed from the wishlist", Toast.LENGTH_LONG).show();
                    productList.remove(getAdapterPosition());
                    notifyItemRemoved(getAdapterPosition());
                    notifyItemRangeChanged(getAdapterPosition(),productList.size());
                }
            });

            imageView = itemView.findViewById(R.id.imageView);
            viewShoppingCart=itemView.findViewById(R.id.viewShoppingCart);
            viewShoppingCart.setTag("remove_from_cart");
            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            textViewZipcode = itemView.findViewById(R.id.textViewZipcode);
            textViewShipping = itemView.findViewById(R.id.textViewShipping);
            textViewCondition = itemView.findViewById(R.id.textViewCondition);
            textViewPrice = itemView.findViewById(R.id.textViewPrice);
        }
    }
}
