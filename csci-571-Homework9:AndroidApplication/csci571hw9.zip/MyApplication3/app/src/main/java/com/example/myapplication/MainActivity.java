package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.TabLayout;
import android.support.design.widget.TextInputLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatAutoCompleteTextView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ProgressBar spinner;
    private Toolbar toolbar;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private EditText keyword,zipcode,miles_from,zipcode_data;
    private TextView sixthTxt;
    private LinearLayout zipcode_layout1;
    private RadioButton radioCurrent,radioZipcode;
    private TextInputLayout keyword_layout,zipcode_layout;
    private static final int TRIGGER_AUTO_COMPLETE = 100;
    private static final long AUTO_COMPLETE_DELAY = 300;
    private Handler handler;
    private AutoSuggestAdapter autoSuggestAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        viewPager = (ViewPager) findViewById(R.id.viewpager);
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(adapter);

        tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);

        RequestQueue queue = Volley.newRequestQueue(this);
        String path = "http://ip-api.com/json";

        StringRequest stringRequest = new StringRequest(Request.Method.GET, path,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the first 500 characters of the response string.
                      try{
                           Global.zip = (String) new JSONObject(response).get("zip");
                      } catch (JSONException e) {
                          e.printStackTrace();
                      }
                      }

                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("fail");
            }
        });
        queue.add(stringRequest);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getSupportActionBar().setHomeButtonEnabled(false);      // Disable the button
        getSupportActionBar().setDisplayHomeAsUpEnabled(false); // Remove the left caret
        getSupportActionBar().setDisplayShowHomeEnabled(false); // Remove the icon
        return true;
    }

    public void onSearchClicked(View view){
        keyword = (EditText) findViewById(R.id.keyword);
        keyword_layout = (TextInputLayout) findViewById(R.id.keyword_layout);
        zipcode = (EditText) findViewById(R.id.zipcode_data);
        zipcode_layout = (TextInputLayout) findViewById(R.id.zipcode_layout);
        radioCurrent = (RadioButton) findViewById(R.id.radioCurrent);
        radioZipcode = (RadioButton) findViewById(R.id.radioZipcode);
        miles_from = (EditText) findViewById(R.id.miles_from);
        zipcode_data= (EditText) findViewById(R.id.zipcode_data);
        CheckBox checkBox = (CheckBox) findViewById(R.id.checkbox_enable_nearby_search);
        CheckBox checkBox_local = (CheckBox) findViewById(R.id.checkbox_local_pickup);
        CheckBox checkBox_free = (CheckBox) findViewById(R.id.checkbox_free_shipping);
        CheckBox checkBox_new = (CheckBox) findViewById(R.id.checkbox_new);
        CheckBox checkBox_used = (CheckBox) findViewById(R.id.checkbox_used);
        CheckBox checkBox_unspecified = (CheckBox) findViewById(R.id.checkbox_unspecified);
        String distance="10";
        Spinner mySpinner=(Spinner) findViewById(R.id.category_spinner);
        String category="";
        if (mySpinner.getSelectedItem().toString().equals("Art")) {
            category="550";
        }
        else
        if (mySpinner.getSelectedItem().toString().equals("Baby")) {
            category="2984";
        }
        else
        if (mySpinner.getSelectedItem().toString().equals("Books")) {
            category="267";
        }
        else
        if (mySpinner.getSelectedItem().toString().equals("Clothing Shoes & Accessories")) {
            category="11450";
        }
        else
        if (mySpinner.getSelectedItem().toString().equals("Computers/Tablets & Networking")) {
            category="58058";
        }
        else
        if (mySpinner.getSelectedItem().toString().equals("Health & Beauty")) {
            category="26395";
        }
        else
        if (mySpinner.getSelectedItem().toString().equals("Music")) {
            category="11233";
        }
        else
        if (mySpinner.getSelectedItem().toString().equals("Video Games & Consoles")) {
            category="1249";
        }
        else
            category="default";

        Boolean keyword_flag=false, zipcode_flag=false;

        if(keyword.getText().toString().equals("") || keyword.getText().toString().trim().length() == 0){
            keyword_layout.setError("Please enter mandatory field");
            keyword_flag=true;
        }

        if(radioZipcode.isChecked() && (zipcode.getText().toString().equals("") || zipcode.getText().toString().trim().length() == 0)){
            zipcode_layout.setError("Please enter mandatory field");
            zipcode_flag=true;
        }

        if(keyword_flag==false && zipcode_flag==false){

            if(checkBox.isChecked() && !miles_from.getText().toString().equals(""))
                distance=miles_from.getText().toString();

            String url ="http://svcs.ebay.com/services/search/FindingService/v1?OPERATION-NAME=findItemsAdvanced&SERVICE-VERSION=1.0.0&SECURITY-APPNAME=MariaFer-Test-PRD-216de56dc-63f77791&RESPONSE-DATA-FORMAT=JSON&RESTPAYLOAD&paginationInput.entriesPerPage=50&";
            if(!category.equals("default")){
                url+="categoryId="+category+"&";
            }
            url+="keywords="+keyword.getText().toString()+"&";
            if(radioCurrent.isChecked()){
                url+="buyerPostalCode="+Global.zip+"&itemFilter(0).name=MaxDistance&itemFilter(0).value="+distance+"&";
            }
            else if(checkBox.isChecked() && radioZipcode.isChecked()){
                url+="buyerPostalCode="+zipcode_data.getText().toString()+"&itemFilter(0).name=MaxDistance&itemFilter(0).value="+distance+"&";
            }

            int i=1;

            if(!checkBox_free.isChecked() && !checkBox_local.isChecked()){
                url+="itemFilter("+i+").name=FreeShippingOnly&itemFilter("+i+").value=true&";
                i++;
                url+="itemFilter("+i+").name=LocalPickUpOnly&itemFilter("+i+").value=true&";
                i++;
            }

            else

            if(checkBox_free.isChecked() && checkBox_local.isChecked()){
                url+="itemFilter("+i+").name=FreeShippingOnly&itemFilter("+i+").value=true&";
                i++;
                url+="itemFilter("+i+").name=LocalPickUpOnly&itemFilter("+i+").value=true&";
                i++;
            }

            else

            if(checkBox_free.isChecked()){
                url+="itemFilter("+i+").name=FreeShippingOnly&itemFilter("+i+").value=true&";
                i++;
                url+="itemFilter("+i+").name=LocalPickUpOnly&itemFilter("+i+").value=false&";
                i++;
            }

            else

            if(checkBox_local.isChecked()){
                url+="itemFilter("+i+").name=FreeShippingOnly&itemFilter("+i+").value=false&";
                i++;
                url+="itemFilter("+i+").name=LocalPickUpOnly&itemFilter("+i+").value=true&";
                i++;
            }

            url+="itemFilter("+i+").name=HideDuplicateItems&itemFilter("+i+").value=true&";
            i++;

            int j=0;
            if(checkBox_new.isChecked() && checkBox_used.isChecked() && checkBox_unspecified.isChecked()){
                url+="itemFilter("+i+").name=Condition&itemFilter("+i+").value("+j+")=New&";
                j++;
                url+="itemFilter("+i+").value("+j+")=Used&";
                j++;
                url+="itemFilter("+i+").value("+j+")=Unspecified&";
            }
            else
            if(!checkBox_new.isChecked() && !checkBox_used.isChecked() && !checkBox_unspecified.isChecked()){
                url+="itemFilter("+i+").name=Condition&itemFilter("+i+").value("+j+")=New&";
                j++;
                url+="itemFilter("+i+").value("+j+")=Used&";
                j++;
                url+="itemFilter("+i+").value("+j+")=Unspecified&";
            }
            else{
                url+="itemFilter("+i+").name=Condition&";
                if(checkBox_new.isChecked()){
                    url+="itemFilter("+i+").value("+j+")=New&";
                    j++;
                }
                if(checkBox_used.isChecked()){
                    url+="itemFilter("+i+").value("+j+")=Used&";
                    j++;
                }
                if(checkBox_unspecified.isChecked()){
                    url+="itemFilter("+i+").value("+j+")=Unspecified&";
                }
            }

            url+="outputSelector(0)=SellerInfo&outputSelector(1)=StoreInfo";

            String encodedurl = "";
            try {
                encodedurl = URLEncoder.encode(url, "UTF-8");
            } catch (Exception e) {
                e.printStackTrace();
            }

            String path="http://csci571-node.us-east-2.elasticbeanstalk.com?key="+encodedurl;

            Bundle sendBundle = new Bundle();
            sendBundle.putString("path", path);
            sendBundle.putString("keyword", keyword.getText().toString());

            Intent intent = new Intent(this, ProductView.class);
            intent.putExtras(sendBundle);
            startActivity(intent);
        }
        else{
            Toast.makeText(this,"Please fix all fields with errors", Toast.LENGTH_LONG).show();
        }
    }




    public void onRadioButtonClicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        RadioButton radioCurrent = (RadioButton) findViewById(R.id.radioCurrent);
        RadioButton radioZipcode = (RadioButton) findViewById(R.id.radioZipcode);
        switch(view.getId()) {
            case R.id.radioCurrent:
                if (checked)
                    radioZipcode.setChecked(false);
                break;
            case R.id.radioZipcode:
                if (checked)
                    radioCurrent.setChecked(false);
                break;
        }
    }

    public void onClearClicked(View view){
        Spinner mySpinner=(Spinner) findViewById(R.id.category_spinner);
        mySpinner.setSelection(0);

        keyword = (EditText) findViewById(R.id.keyword);
        keyword.setText("");
        keyword_layout = (TextInputLayout) findViewById(R.id.keyword_layout);
        keyword_layout.setError("");


        zipcode = (EditText) findViewById(R.id.zipcode_data);
        zipcode.setText("");
        zipcode_layout = (TextInputLayout) findViewById(R.id.zipcode_layout);
        zipcode_layout.setError("");

        radioCurrent = (RadioButton) findViewById(R.id.radioCurrent);
        radioCurrent.setChecked(true);
        radioZipcode = (RadioButton) findViewById(R.id.radioZipcode);
        radioZipcode.setChecked(false);

        CheckBox checkBox = (CheckBox) findViewById(R.id.checkbox_enable_nearby_search);
        checkBox.setChecked(false);

        CheckBox checkBox_local = (CheckBox) findViewById(R.id.checkbox_local_pickup);
        checkBox_local.setChecked(false);
        CheckBox checkBox_free = (CheckBox) findViewById(R.id.checkbox_free_shipping);
        checkBox_free.setChecked(false);

        CheckBox checkBox_new = (CheckBox) findViewById(R.id.checkbox_new);
        checkBox_new.setChecked(false);
        CheckBox checkBox_used = (CheckBox) findViewById(R.id.checkbox_used);
        checkBox_used.setChecked(false);
        CheckBox checkBox_unspecified = (CheckBox) findViewById(R.id.checkbox_unspecified);
        checkBox_unspecified.setChecked(false);

        miles_from = (EditText) findViewById(R.id.miles_from);
        sixthTxt = (TextView) findViewById(R.id.sixthTxt);
        radioCurrent = (RadioButton) findViewById(R.id.radioCurrent);
        radioZipcode = (RadioButton) findViewById(R.id.radioZipcode);
        zipcode_data= (EditText) findViewById(R.id.zipcode_data);
        zipcode_layout1= (LinearLayout) findViewById(R.id.zipcode_layout1);

        miles_from.setText("");
        miles_from.setVisibility(View.GONE);
        sixthTxt.setVisibility(View.GONE);
        radioCurrent.setVisibility(View.GONE);
        zipcode_data.setVisibility(View.GONE);
        zipcode_layout1.setVisibility(View.GONE);
    }

    public void onEnableNearbySearch(View view){
        miles_from = (EditText) findViewById(R.id.miles_from);
        sixthTxt = (TextView) findViewById(R.id.sixthTxt);
        radioCurrent = (RadioButton) findViewById(R.id.radioCurrent);
        radioZipcode = (RadioButton) findViewById(R.id.radioZipcode);
        zipcode_data= (EditText) findViewById(R.id.zipcode_data);
        zipcode_layout1= (LinearLayout) findViewById(R.id.zipcode_layout1);
        CheckBox checkBox = (CheckBox) findViewById(R.id.checkbox_enable_nearby_search);
        if (checkBox.isChecked()) {
            miles_from.setVisibility(View.VISIBLE);
            sixthTxt.setVisibility(View.VISIBLE);
            radioCurrent.setVisibility(View.VISIBLE);
            zipcode_data.setVisibility(View.VISIBLE);
            zipcode_layout1.setVisibility(View.VISIBLE);
            final AppCompatAutoCompleteTextView autoCompleteTextView =
                    findViewById(R.id.zipcode_data);
            final TextView selectedText = findViewById(R.id.selected_item);

            //Setting up the adapter for AutoSuggest
            autoSuggestAdapter = new AutoSuggestAdapter(this,
                    android.R.layout.simple_dropdown_item_1line);
            autoCompleteTextView.setThreshold(1);
            autoCompleteTextView.setAdapter(autoSuggestAdapter);
            autoCompleteTextView.setOnItemClickListener(
                    new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view,
                                                int position, long id) {
                            selectedText.setText(autoSuggestAdapter.getObject(position));
                        }
                    });

            autoCompleteTextView.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int
                        count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before,
                                          int count) {
                    handler.removeMessages(TRIGGER_AUTO_COMPLETE);
                    handler.sendEmptyMessageDelayed(TRIGGER_AUTO_COMPLETE,
                            AUTO_COMPLETE_DELAY);
                }

                @Override
                public void afterTextChanged(Editable s) {

                }
            });

            handler = new Handler(new Handler.Callback() {
                @Override
                public boolean handleMessage(Message msg) {
                    if (msg.what == TRIGGER_AUTO_COMPLETE) {
                        if (!TextUtils.isEmpty(autoCompleteTextView.getText())) {
                            makeApiCall(autoCompleteTextView.getText().toString());
                        }
                    }
                    return false;
                }
            });
        }
        else{
            miles_from.setVisibility(View.GONE);
            sixthTxt.setVisibility(View.GONE);
            radioCurrent.setVisibility(View.GONE);
            zipcode_data.setVisibility(View.GONE);
            zipcode_layout1.setVisibility(View.GONE);

        }
    }

    private void makeApiCall(String text) {
        ApiCall.make(this, text, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //parsing logic, please change it as per your requirement
                List<String> stringList = new ArrayList<>();
                try {
                    JSONObject responseObject = new JSONObject(response);
                    JSONArray array = responseObject.getJSONArray("postalCodes");
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject row = array.getJSONObject(i);
                        stringList.add(row.getString("postalCode"));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                //IMPORTANT: set data here and notify
                autoSuggestAdapter.setData(stringList);
                autoSuggestAdapter.notifyDataSetChanged();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
    }

}