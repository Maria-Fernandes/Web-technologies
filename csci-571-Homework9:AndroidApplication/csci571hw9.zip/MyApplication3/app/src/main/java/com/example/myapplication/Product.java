package com.example.myapplication;

public class Product {
    private String id;
    private String image;
    private String title;
    private String zipcode;
    private String shipping;
    private String condition;
    private String price;
    private int icon;


    public Product( String id,String image,String title, String zipcode, String shipping, String condition, String price,int icon) {
        this.id=id;
        this.image = image;
        this.title = title;
        this.zipcode = zipcode;
        this.shipping = shipping;
        this.condition = condition;
        this.price = price;
        this.icon=icon;

    }

    public String getId() {
        return id;
    }

    public String getImage() {
        return image;
    }

    public String getTitle() {
        return title;
    }

    public String getZipcode() {
        return zipcode;
    }

    public String getShipping() {
        return shipping;
    }

    public String getCondition() {
        return condition;
    }

    public String getPrice() {
        return price;
    }

    public int getIcon() {
        return icon;
    }


    public void setIcon(int icon) {
        this.icon=icon;
    }



}

