package com.example.myapplication;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class ProductView extends AppCompatActivity {

    //a list to store all the products
    List<Product> productList;

    //the recyclerview
    RecyclerView recyclerView;

    private ProgressBar spinner;
    private LinearLayout textView;
    private TextView text_spinner;
    private LinearLayout displayItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_view);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        RequestQueue queue = Volley.newRequestQueue(this);

        Bundle receiveBundle = this.getIntent().getExtras();
        String path = receiveBundle.getString("path");

        spinner = (ProgressBar)findViewById(R.id.progressBar);
        spinner.setVisibility(View.VISIBLE);
        text_spinner = (TextView)findViewById(R.id.progress_text);
        text_spinner.setVisibility(View.VISIBLE);
        displayItems=(LinearLayout) findViewById(R.id.displayItems);
        displayItems.setVisibility(View.GONE);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, path,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the first 500 characters of the response string.
                        generateRecycleView(response);
                        spinner = (ProgressBar)findViewById(R.id.progressBar);
                        spinner.setVisibility(View.GONE);
                        text_spinner = (TextView)findViewById(R.id.progress_text);
                        text_spinner.setVisibility(View.GONE);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("fail");
            }
        });
        queue.add(stringRequest);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getSupportActionBar().setHomeButtonEnabled(true);      // Disable the button
        getSupportActionBar().setDisplayHomeAsUpEnabled(true); // Remove the left caret
        getSupportActionBar().setDisplayShowHomeEnabled(true); // Remove the icon
        return true;
    }

    public void generateRecycleView(String response){
        SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("response", response);
        editor.commit();
        Global.jsonInitialResponse=response;
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setVisibility(View.VISIBLE);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        productList = new ArrayList<>();

        try {
            JSONObject findItemsAdvancedResponse = (JSONObject) new JSONObject(response).getJSONArray("findItemsAdvancedResponse").get(0);
            JSONObject searchResult= (JSONObject) findItemsAdvancedResponse.getJSONArray("searchResult").get(0);
            if(searchResult.has("item")){
                displayItems=(LinearLayout) findViewById(R.id.displayItems);
                displayItems.setVisibility(View.VISIBLE);
                LinearLayout error=(LinearLayout) findViewById(R.id.error);
                error.setVisibility(View.GONE);
                TextView error_data=(TextView) findViewById(R.id.error_data);
                error_data.setVisibility(View.GONE);
                JSONArray items=searchResult.getJSONArray("item");
                TextView number=(TextView)findViewById(R.id.number);
                number.setText(Integer.toString(items.length()));
                TextView keyword=(TextView)findViewById(R.id.keyword);
                Bundle receiveBundle = this.getIntent().getExtras();
                String word = receiveBundle.getString("keyword");
                keyword.setText(word);
                for(int i=0;i<items.length();i++){
                    JSONObject json= items.getJSONObject(i);
                    String id="N/A";
                    String image="";
                    String title="N/A";
                    String zipcode="N/A";
                    String shipping="0.0";
                    String condition="N/A";
                    String price ="N/A";
                    if(json.has("itemId"))
                        id=(String) json.getJSONArray("itemId").get(0);
                    if(json.has("galleryURL"))
                        image= (String) json.getJSONArray("galleryURL").get(0);
                    if(json.has("title"))
                        title= (String) json.getJSONArray("title").get(0);
                    if(json.has("postalCode"))
                        zipcode= (String) "Zip: "+json.getJSONArray("postalCode").get(0);
                    if(json.has("shippingInfo")){
                        JSONObject shipprop1= (JSONObject) json.getJSONArray("shippingInfo").get(0);
                        JSONObject shipprop2= (JSONObject) shipprop1.getJSONArray("shippingServiceCost").get(0);
                        shipping= (String) shipprop2.get("__value__");
                        if(Float.parseFloat(shipping)==0.0){
                            shipping="Free Shipping";
                        }
                        else
                            shipping=shipping+" USD";
                    }

                    if(json.has("condition")) {
                        JSONObject conditionprop1 = (JSONObject) json.getJSONArray("condition").get(0);
                        condition = (String) conditionprop1.getJSONArray("conditionDisplayName").get(0);
                        if (condition.contains("refurbished"))
                            condition = "Refurbished";
                    }

                    if(json.has("sellingStatus")) {
                        JSONObject priceprop1 = (JSONObject) json.getJSONArray("sellingStatus").get(0);
                        JSONObject priceprop2 = (JSONObject) priceprop1.getJSONArray("currentPrice").get(0);
                        price = (String) "$" + priceprop2.get("__value__");
                    }


                    productList.add(
                            new Product(id,image,title,zipcode,shipping,condition,price,R.drawable.cart_plus));
                }
                //creating recyclerview adapter
                ProductAdapter adapter = new ProductAdapter(this, productList);
                //setting adapter to recyclerview
                recyclerView.setAdapter(adapter);
            }
            else{
                displayItems=(LinearLayout) findViewById(R.id.displayItems);
                displayItems.setVisibility(View.GONE);
                recyclerView.setVisibility(View.GONE);
                LinearLayout error=(LinearLayout) findViewById(R.id.error);
                error.setVisibility(View.VISIBLE);
                TextView error_data=(TextView) findViewById(R.id.error_data);
                error_data.setText("No Records");
                error_data.setVisibility(View.VISIBLE);

            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


}

