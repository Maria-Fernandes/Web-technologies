package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;


import com.squareup.picasso.Picasso;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;


public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {


    //this context we will use to inflate the layout
    private Context mCtx;

    //we are storing all the products in a list
    private List<Product> productList;

    private ProgressBar spinner;

    DbAdapter db;
    SimpleCursorAdapter adapter;

    //getting the context and product list with constructor
    public ProductAdapter(Context mCtx, List<Product> productList) {
        this.mCtx = mCtx;
        this.productList = productList;
    }

    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflating and returning our view holder
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.layout_products, null);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ProductViewHolder holder, int position) {
        //getting the product of the specified position
        Product product = productList.get(position);

        //binding the data with the viewholder views
        if(product.getImage()!=""){
            Picasso.with(holder.imageView.getContext()).load(product.getImage()).into(holder.imageView);
        }
        else{
            Picasso.with(holder.imageView.getContext()).load(R.drawable.star_circle).into(holder.imageView);
        }
        holder.viewShoppingCart.setImageDrawable(mCtx.getResources().getDrawable(product.getIcon()));
        if(Global.list!=null){
            if(Global.list.get(position).getIcon()!=0){
                holder.viewShoppingCart.setImageDrawable(mCtx.getResources().getDrawable(product.getIcon()));
            }
        }
        holder.textViewTitle.setText(product.getTitle());
        holder.textViewZipcode.setText(product.getZipcode());
        holder.textViewShipping.setText(product.getShipping());
        holder.textViewCondition.setText(product.getCondition());
        holder.textViewPrice.setText(product.getPrice());


    }


    @Override
    public int getItemCount() {
        return productList.size();
    }


    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView textViewTitle, textViewZipcode, textViewShipping,textViewCondition, textViewPrice;
        ImageView imageView,viewShoppingCart,itemSelected,wishListClicked;

        public ProductViewHolder(View itemView) {
            super(itemView);
            itemSelected = (ImageView) itemView.findViewById(R.id.imageView);
            itemSelected.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v){
                  int pos=getAdapterPosition();
                  String id=productList.get(pos).getId();
                  String title=productList.get(pos).getTitle();
                  Global.selectedItemId=id;
                  Bundle sendBundle = new Bundle();
                  sendBundle.putString("id", id);
                  sendBundle.putString("title",title);
                  ViewGroup row = (ViewGroup) v.getParent();
                  ImageView img = (ImageView) row.findViewById(R.id.viewShoppingCart);
                  Global.imgView=img;
                  Global.list=productList;
                  Global.pos=pos;
                  if(img.getTag().toString().equals("add_to_cart")){
                      sendBundle.putString("icon","add");
                  }
                  else{
                      sendBundle.putString("icon","remove");
                  }

                  Intent intent = new Intent(mCtx, SelectedItem.class);
                  intent.putExtras(sendBundle);
                  mCtx.startActivity(intent);
              }
            });

            wishListClicked = (ImageView) itemView.findViewById(R.id.viewShoppingCart);
            wishListClicked.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v){
                    db = new DbAdapter(v.getContext());
                    db.open();
                    int pos=getAdapterPosition();
                    String id=productList.get(pos).getId();
                    String image=productList.get(pos).getImage();
                    String title=productList.get(pos).getTitle();
                    String zipcode=productList.get(pos).getZipcode();
                    String shipping=productList.get(pos).getShipping();
                    String condition=productList.get(pos).getCondition();
                    String price=productList.get(pos).getPrice();

                    int icon=productList.get(pos).getIcon();
                    if(wishListClicked.getTag().toString().equals("add_to_cart")){
                        wishListClicked.setImageResource(R.drawable.cart_remove);
                        wishListClicked.setTag("remove_from_cart");
                        db.insert(id,image,title,zipcode,shipping,condition,price,R.drawable.cart_remove);
                        productList.get(pos).setIcon(R.drawable.cart_remove);
                        notifyItemChanged(pos);
                        Toast.makeText(v.getContext(),title+" was added to the wishlist", Toast.LENGTH_LONG).show();
                    }
                    else{
                        wishListClicked.setImageResource(R.drawable.cart_plus);
                        wishListClicked.setTag("add_to_cart");
                        db.delete(id);
                        productList.get(pos).setIcon(R.drawable.cart_plus);
                        notifyItemChanged(pos);
                        Toast.makeText(v.getContext(),title+" was removed from the wishlist", Toast.LENGTH_LONG).show();
                    }
                }
            });

            imageView = itemView.findViewById(R.id.imageView);
            viewShoppingCart=itemView.findViewById(R.id.viewShoppingCart);
            viewShoppingCart.setTag("add_to_cart");
            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            textViewZipcode = itemView.findViewById(R.id.textViewZipcode);
            textViewShipping = itemView.findViewById(R.id.textViewShipping);
            textViewCondition = itemView.findViewById(R.id.textViewCondition);
            textViewPrice = itemView.findViewById(R.id.textViewPrice);
        }
    }
}
