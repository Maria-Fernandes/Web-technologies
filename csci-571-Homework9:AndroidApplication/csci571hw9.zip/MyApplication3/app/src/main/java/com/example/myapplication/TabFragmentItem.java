package com.example.myapplication;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;
import com.wssholmes.stark.circular_score.CircularScoreView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import static com.facebook.FacebookSdk.getApplicationContext;

public class TabFragmentItem extends Fragment {

    int position;
    private TextView textView;
    private LinearLayout mGallery;
    private Toolbar toolbar;
    private ProgressBar spinner;
    private TextView text_spinner;

    //a list to store all the products
    List<SimilarItem> itemList;

    //the recyclerview
    RecyclerView recyclerView;

    public static Fragment getInstance(int position) {
        Bundle bundle = new Bundle();
        bundle.putInt("pos", position);
        TabFragmentItem tabFragment = new TabFragmentItem();
        tabFragment.setArguments(bundle);
        return tabFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        position = getArguments().getInt("pos");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=null;
        String response=Global.jsonResponse;
        SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
        SharedPreferences.Editor editor = pref.edit();
//        String initialResponse=Global.jsonInitialResponse;
        String initialResponse=pref.getString("response", null);
        String data = "";


        try {

            JSONObject findItemsAdvancedResponse = (JSONObject) new JSONObject(initialResponse).getJSONArray("findItemsAdvancedResponse").get(0);
            JSONObject searchResult = (JSONObject) findItemsAdvancedResponse.getJSONArray("searchResult").get(0);
            JSONArray items = searchResult.getJSONArray("item");
            for (int i = 0; i < items.length(); i++) {
                JSONObject json= items.getJSONObject(i);
                String id=(String) json.getJSONArray("itemId").get(0);
                if(id.toString().equals(Global.selectedItemId)){
                    data=json.toString();
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if(position==0) {
            try {
                Boolean flag1=false,flag2=false;
                view=inflater.inflate(R.layout.product_tab, container, false);
                TextView noresults = (TextView) view.findViewById(R.id.noresults);
                noresults.setVisibility(View.GONE);
                JSONObject resObj = (JSONObject) new JSONObject(response).getJSONObject("Item");
                String ViewItemURLForNaturalSearch= "";
                String title="";
                String price="";
                String brand="";
                String items="";
                JSONArray pictureUrl=null;
                JSONObject jsonObj = new JSONObject();

                if(resObj.has("Title")){
                    title= (String) resObj.get("Title");
                    jsonObj.put("title", (String) resObj.get("Title"));
                }

                if(resObj.has("ViewItemURLForNaturalSearch"))
                ViewItemURLForNaturalSearch= (String) resObj.get("ViewItemURLForNaturalSearch");

                if(resObj.has("CurrentPrice"))
                price=resObj.getJSONObject("CurrentPrice").getString("Value");

                Global.title=title;
                Global.url=ViewItemURLForNaturalSearch;
                Global.price=price;

                if(resObj.has("PictureURL")){
                    pictureUrl=resObj.getJSONArray("PictureURL");
                    LinearLayout galleryLayout = (LinearLayout) view.findViewById(R.id.id_gallery);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    for(int i=0;i<pictureUrl.length();i++){
                        ImageView iv = new ImageView(view.getContext());
                        iv.setId(i);
                        iv.setLayoutParams(lp);
                        galleryLayout.addView(iv);
                        Picasso.with(view.getContext()).load(pictureUrl.get(i).toString()).resize(770,500).into(iv);
                    }
                }

                if(resObj.has("ItemSpecifics")){
                    JSONArray itemSpecifics=resObj.getJSONObject("ItemSpecifics").getJSONArray("NameValueList");
                    LinearLayout lLayout = (LinearLayout) view.findViewById(R.id.layout);
                    for(int i=0;i<itemSpecifics.length();i++){
                        String name=itemSpecifics.getJSONObject(i).getString("Name");
                        if(name.toString().equals("Brand")){
                            brand=itemSpecifics.getJSONObject(i).getJSONArray("Value").get(0).toString();
                        }
                        else{
                            items="•"+itemSpecifics.getJSONObject(i).getJSONArray("Value").get(0).toString().substring(0, 1).toUpperCase()+
                                    itemSpecifics.getJSONObject(i).getJSONArray("Value").get(0).toString().substring(1).toLowerCase()+"";
                            TextView tv = new TextView(view.getContext()); // Prepare textview object programmatically
                            tv.setText(items);
                            tv.setId(i);
                            tv.setPadding(70,0,0,0);
                            lLayout.addView(tv);
                        }
                    }
                }

                JSONObject info = (JSONObject) new JSONObject(data);
                String shipping="";
                JSONObject shipprop2=null,shipprop1=null;

                if(info.has("shippingInfo")){
                    shipprop1= (JSONObject) info.getJSONArray("shippingInfo").get(0);
                    if(shipprop1.has("shippingServiceCost")){
                        shipprop2= (JSONObject) shipprop1.getJSONArray("shippingServiceCost").get(0);
                        shipping= (String) shipprop2.get("__value__");
                        if(Float.parseFloat(shipping)==0.0){
                            shipping="with Free Shipping";
                        }
                        else
                            shipping="with "+shipping+" USD Shipping";
                    }
                }


                TextView textViewTitleToChange = (TextView) view.findViewById(R.id.textViewTitle);
                textViewTitleToChange.setText(title);
                TextView textViewPriceDescription = (TextView) view.findViewById(R.id.textViewPriceDescription);
                textViewPriceDescription.setText(shipping);
                TextView textViewPriceToChange = (TextView) view.findViewById(R.id.textViewPrice);
                textViewPriceToChange.setText("$ "+price);

                if(price!=""){
                    TextView textViewPriceDataToChange = (TextView) view.findViewById(R.id.pricedata);
                    textViewPriceDataToChange.setText("$ "+price);
                }
                else{
                    TextView textViewPrice = (TextView) view.findViewById(R.id.price);
                    textViewPrice.setVisibility(View.GONE);
                    TextView textViewPriceDataToChange = (TextView) view.findViewById(R.id.pricedata);
                    textViewPriceDataToChange.setVisibility(View.GONE);
                }

                if(brand!=""){
                    TextView textViewBrandToChange = (TextView) view.findViewById(R.id.branddata);
                    textViewBrandToChange.setText(brand);
                    TextView textViewSpecificationBrandToChange = (TextView) view.findViewById(R.id.textViewSpecificationsBrandData);
                    textViewSpecificationBrandToChange.setText("•"+brand);
                }
                else{
                    TextView textViewBrand = (TextView) view.findViewById(R.id.brand);
                    textViewBrand.setVisibility(View.GONE);
                    TextView textViewBrandToChange = (TextView) view.findViewById(R.id.branddata);
                    textViewBrandToChange.setVisibility(View.GONE);
                }

                if(brand=="" && price==""){
                    View view1=(View)view.findViewById(R.id.view1);
                    view1.setVisibility(View.GONE);
                    LinearLayout layout1=(LinearLayout)view.findViewById(R.id.section1);
                    layout1.setVisibility(View.GONE);
                    flag1=true;
                }

                if(items==""){
                    View view2=(View)view.findViewById(R.id.view2);
                    view2.setVisibility(View.GONE);
                    LinearLayout layout2=(LinearLayout)view.findViewById(R.id.section2);
                    layout2.setVisibility(View.GONE);
                    flag2=true;
                }

                if(resObj.has("ItemID"))
                jsonObj.put("id",(String) resObj.get("ItemID"));
                if(resObj.has("GalleryURL"))
                jsonObj.put("image", (String) resObj.get("GalleryURL"));
                if(resObj.has("PostalCode"))
                jsonObj.put("zipcode", "Zip: "+(String) resObj.get("PostalCode"));
                if(shipprop2.has("__value__")){
                    String shipp= (String) shipprop2.get("__value__");
                    if(Float.parseFloat(shipp)==0.0){
                        shipp="Free Shipping";
                    }
                    else
                        shipp=shipp+"USD";
                    jsonObj.put("shipping", shipp);
                }

                if(resObj.has("ConditionDisplayName")){
                    String condition=(String) resObj.get("ConditionDisplayName");
                    if(condition.contains("refurbished"))
                        condition="Refurbished";
                    jsonObj.put("condition", condition);
                    jsonObj.put("price", "$ "+price);
                }
                Global.jsonObj=jsonObj;

                if(flag1==true && flag2==true ){
                    if(title.equals("") && price.equals("") && shipping.equals("") ){
                        HorizontalScrollView hlayout3=(HorizontalScrollView)view.findViewById(R.id.view);
                        hlayout3.setVisibility(View.GONE);
                        View view3=(View)view.findViewById(R.id.view3);
                        view3.setVisibility(View.GONE);
                        LinearLayout layout3=(LinearLayout)view.findViewById(R.id.section3);
                        layout3.setVisibility(View.GONE);
                        TextView textViewSpecificationsBrandData = (TextView) view.findViewById(R.id.textViewSpecificationsBrandData);
                        textViewSpecificationsBrandData.setVisibility(View.GONE);
                        noresults = (TextView) view.findViewById(R.id.noresults);
                        noresults.setVisibility(View.VISIBLE);

                    }

                }
                View test=inflater.inflate(R.layout.activity_selected_item, container, false);
                return view;

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        else
        if(position==1) {
            view=inflater.inflate(R.layout.shipping_tab, container, false);
            try {
                TextView noresults = (TextView) view.findViewById(R.id.noresults);
                noresults.setVisibility(View.GONE);
                JSONObject info = (JSONObject) new JSONObject(data);
                JSONArray store=null;
                String shipping="";

                if(info.has("storeInfo")){
                    store= (JSONArray) info.getJSONArray("storeInfo");
                    String storeinfo= (String) store.getJSONObject(0).getJSONArray("storeName").get(0);
                    String storeinfourl= (String) store.getJSONObject(0).getJSONArray("storeURL").get(0);
                    TextView stores = (TextView) view.findViewById(R.id.store);
                    stores.setText(Html.fromHtml("<a href=\""+ storeinfourl + "\">" + storeinfo + "</a>"));
                    stores.setClickable(true);
                    stores.setMovementMethod (LinkMovementMethod.getInstance());
                }
                else{
                    TextView storeName = (TextView) view.findViewById(R.id.storeName);
                    storeName.setVisibility(View.GONE);
                    TextView stores = (TextView) view.findViewById(R.id.store);
                    stores.setVisibility(View.GONE);
                }

                if(info.has("sellerInfo")){
                    JSONArray seller= (JSONArray) info.getJSONArray("sellerInfo");
                    String feedbackScore= (String) seller.getJSONObject(0).getJSONArray("feedbackScore").get(0);
                    String popularity= (String) seller.getJSONObject(0).getJSONArray("positiveFeedbackPercent").get(0);

                    TextView score = (TextView) view.findViewById(R.id.score);
                    score.setText(feedbackScore);
                    CircularScoreView circularScoreView = (CircularScoreView) view.findViewById(R.id.score_view);
                    circularScoreView.setScore(Math.round(Float.parseFloat(popularity)));
                    ImageView image = (ImageView) view.findViewById(R.id.star);
                    if(Integer.parseInt(feedbackScore)>=10 && Integer.parseInt(feedbackScore)<=49){
                        image.setImageResource(R.drawable.star_circle_outline);
                        int color = Color.parseColor("#ffff00");
                        image.setColorFilter(color);
                    }
                    else
                    if(Integer.parseInt(feedbackScore)>=50 && Integer.parseInt(feedbackScore)<=99){
                        image.setImageResource(R.drawable.star_circle_outline);
                        int color = Color.parseColor("#66ccff");
                        image.setColorFilter(color);
                    }
                    else
                    if(Integer.parseInt(feedbackScore)>=100 && Integer.parseInt(feedbackScore)<=499){
                        image.setImageResource(R.drawable.star_circle_outline);
                        int color = Color.parseColor("#40e0d0");
                        image.setColorFilter(color);
                    }
                    else
                    if(Integer.parseInt(feedbackScore)>=500 && Integer.parseInt(feedbackScore)<=999){
                        image.setImageResource(R.drawable.star_circle_outline);
                        int color = Color.parseColor("#990099");
                        image.setColorFilter(color);
                    }
                    else
                    if(Integer.parseInt(feedbackScore)>=1000 && Integer.parseInt(feedbackScore)<=4999){
                        image.setImageResource(R.drawable.star_circle_outline);
                        int color = Color.parseColor("#ff0000");
                        image.setColorFilter(color);
                    }
                    else
                    if(Integer.parseInt(feedbackScore)>=5000 && Integer.parseInt(feedbackScore)<=9999){
                        image.setImageResource(R.drawable.star_circle_outline);
                        int color = Color.parseColor("#66ff33");
                        image.setColorFilter(color);
                    }
                    else
                    if(Integer.parseInt(feedbackScore)>=10000 && Integer.parseInt(feedbackScore)<=24999){
                        image.setImageResource(R.drawable.star_circle);
                        int color = Color.parseColor("#ffff00");
                        image.setColorFilter(color);
                    }
                    else
                    if(Integer.parseInt(feedbackScore)>=25000 && Integer.parseInt(feedbackScore)<=49999){
                        image.setImageResource(R.drawable.star_circle);
                        int color = Color.parseColor("#40e0d0");
                        image.setColorFilter(color);
                    }
                    else
                    if(Integer.parseInt(feedbackScore)>=50000 && Integer.parseInt(feedbackScore)<=99999){
                        image.setImageResource(R.drawable.star_circle);
                        int color = Color.parseColor("#66ff33");
                        image.setColorFilter(color);
                    }
                    else
                    if(Integer.parseInt(feedbackScore)>=100000 && Integer.parseInt(feedbackScore)<=499999){
                        image.setImageResource(R.drawable.star_circle);
                        int color = Color.parseColor("#ff0000");
                        image.setColorFilter(color);
                    }
                    else
                    if(Integer.parseInt(feedbackScore)>=500000 && Integer.parseInt(feedbackScore)<=900000){
                        image.setImageResource(R.drawable.star_circle);
                        int color = Color.parseColor("#990099");
                        image.setColorFilter(color);
                    }
                    if(Integer.parseInt(feedbackScore)>=1000000 ){
                        image.setImageResource(R.drawable.star_circle);
                        int color = Color.parseColor("#c0c0c0");
                        image.setColorFilter(color);
                    }
                }

                Boolean flag1=false,flag2=false,flag3=false;

                if(!info.has("storeInfo") && !info.has("sellerInfo")){
                    View view1=(View)view.findViewById(R.id.view1);
                    view1.setVisibility(View.GONE);
                    LinearLayout layout1=(LinearLayout)view.findViewById(R.id.section1);
                    layout1.setVisibility(View.GONE);
                    flag1=true;
                }

                if(info.has("shippingInfo")){
                    JSONObject shipprop1= (JSONObject) info.getJSONArray("shippingInfo").get(0);
                    JSONObject shipprop2= (JSONObject) shipprop1.getJSONArray("shippingServiceCost").get(0);
                    shipping= (String) shipprop2.get("__value__");
                    if(Float.parseFloat(shipping)==0.0){
                        shipping="Free Shipping";
                    }
                    else
                        shipping=shipping+" USD";
                    TextView cost = (TextView) view.findViewById(R.id.cost);
                    cost.setText(shipping);
                }
                else{
                    TextView costName = (TextView) view.findViewById(R.id.costName);
                    costName.setVisibility(View.GONE);
                    TextView cost = (TextView) view.findViewById(R.id.cost);
                    cost.setVisibility(View.GONE);
                }

                String gShip="";
                String handle="";
                Boolean globalShipping;
                JSONObject resObj = (JSONObject) new JSONObject(response).getJSONObject("Item");

                if(resObj.has("GlobalShipping")){
                    globalShipping= (Boolean) resObj.get("GlobalShipping");
                    if(globalShipping==true)
                        gShip="Yes";
                    else
                        gShip="No";

                    TextView shipin = (TextView) view.findViewById(R.id.shipping);
                    shipin.setText(gShip);
                }
                else{
                    TextView shipinName = (TextView) view.findViewById(R.id.shippingName);
                    shipinName.setVisibility(View.GONE);
                    TextView shipin = (TextView) view.findViewById(R.id.shipping);
                    shipin.setVisibility(View.GONE);
                }

                Integer handlingTime=null;
                if(resObj.has("HandlingTime")) {
                    handlingTime = (Integer) resObj.get("HandlingTime");
                    if (handlingTime == 0 || handlingTime == 1)
                        handle = handlingTime + " Day";
                    else
                        handle = handlingTime + " Days";

                    TextView handling = (TextView) view.findViewById(R.id.handling);
                    handling.setText(handle);
                }else{
                    TextView handlingName = (TextView) view.findViewById(R.id.handlingName);
                    handlingName.setVisibility(View.GONE);
                    TextView handling = (TextView) view.findViewById(R.id.handling);
                    handling.setVisibility(View.GONE);
                }

                String condition_desc="";
                if(resObj.has("ConditionDescription")) {
                    condition_desc = (String) resObj.get("ConditionDescription");
                    TextView condition = (TextView) view.findViewById(R.id.condition);
                    condition.setText(condition_desc);
                }
                else{
                    TextView conditionName = (TextView) view.findViewById(R.id.conditionName);
                    conditionName.setVisibility(View.GONE);
                    TextView condition = (TextView) view.findViewById(R.id.condition);
                    condition.setVisibility(View.GONE);
                }

                if(condition_desc=="" && handlingTime==null && gShip=="" && !info.has("shippingInfo")){
                    View view2=(View)view.findViewById(R.id.view2);
                    view2.setVisibility(View.GONE);
                    LinearLayout layout2=(LinearLayout)view.findViewById(R.id.section2);
                    layout2.setVisibility(View.GONE);
                    flag2=true;
                }


                String returnAccepted="";
                String returnWithin="";
                String returnRefund="";
                String returnCost="";
                if(resObj.has("ReturnPolicy")){
                    if(resObj.getJSONObject("ReturnPolicy").has("ReturnsAccepted")){
                        returnAccepted=resObj.getJSONObject("ReturnPolicy").getString("ReturnsAccepted");
                        TextView policy = (TextView) view.findViewById(R.id.policy);
                        policy.setText(returnAccepted);
                    }
                    else{
                        TextView policyName = (TextView) view.findViewById(R.id.policyName);
                        policyName.setVisibility(View.GONE);
                        TextView policy = (TextView) view.findViewById(R.id.policy);
                        policy.setVisibility(View.GONE);

                    }

                    if(resObj.getJSONObject("ReturnPolicy").has("ReturnsWithin")){
                        returnWithin=resObj.getJSONObject("ReturnPolicy").getString("ReturnsWithin");
                        TextView returns = (TextView) view.findViewById(R.id.returns);
                        returns.setText(returnWithin);
                    }
                    else{
                        TextView returns = (TextView) view.findViewById(R.id.returns);
                        returns.setVisibility(View.GONE);
                        TextView returnsName = (TextView) view.findViewById(R.id.returnsName);
                        returnsName.setVisibility(View.GONE);

                    }

                    if(resObj.getJSONObject("ReturnPolicy").has("Refund")){
                        returnRefund=resObj.getJSONObject("ReturnPolicy").getString("Refund");
                        TextView refund = (TextView) view.findViewById(R.id.refund);
                        refund.setText(returnRefund);
                    }
                    else{
                        TextView refund = (TextView) view.findViewById(R.id.refund);
                        refund.setVisibility(View.GONE);
                        TextView refundName = (TextView) view.findViewById(R.id.refundName);
                        refundName.setVisibility(View.GONE);

                    }

                    if(resObj.getJSONObject("ReturnPolicy").has("ShippingCostPaidBy")){
                        returnCost=resObj.getJSONObject("ReturnPolicy").getString("ShippingCostPaidBy");
                        TextView shipped = (TextView) view.findViewById(R.id.shipped);
                        shipped.setText(returnCost);
                    }else{
                        TextView shipped = (TextView) view.findViewById(R.id.shipped);
                        shipped.setVisibility(View.GONE);
                        TextView shippedName = (TextView) view.findViewById(R.id.shippedName);
                        shippedName.setVisibility(View.GONE);
                    }
                }
                else{
                    TextView policyName = (TextView) view.findViewById(R.id.policyName);
                    policyName.setVisibility(View.GONE);
                    TextView policy = (TextView) view.findViewById(R.id.policy);
                    policy.setVisibility(View.GONE);

                    TextView returns = (TextView) view.findViewById(R.id.returns);
                    returns.setVisibility(View.GONE);
                    TextView returnsName = (TextView) view.findViewById(R.id.returnsName);
                    returnsName.setVisibility(View.GONE);

                    TextView refund = (TextView) view.findViewById(R.id.refund);
                    refund.setVisibility(View.GONE);
                    TextView refundName = (TextView) view.findViewById(R.id.refundName);
                    refundName.setVisibility(View.GONE);

                    TextView shipped = (TextView) view.findViewById(R.id.shipped);
                    shipped.setVisibility(View.GONE);
                    TextView shippedName = (TextView) view.findViewById(R.id.shippedName);
                    shippedName.setVisibility(View.GONE);

                }

                if(!resObj.has("ReturnPolicy")){
                    View view3=(View)view.findViewById(R.id.view3);
                    view3.setVisibility(View.GONE);
                    LinearLayout layout3=(LinearLayout)view.findViewById(R.id.section3);
                    layout3.setVisibility(View.GONE);
                    flag3=true;
                }

                if(flag1==true && flag2==true && flag3==true){
                    noresults = (TextView) view.findViewById(R.id.noresults);
                    noresults.setVisibility(View.VISIBLE);
                }

                return view;
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        else
            if(position==2){
                try {
                    view = inflater.inflate(R.layout.photos_tab, container, false);
                    RequestQueue queue = Volley.newRequestQueue(view.getContext());
                    JSONObject resObj = (JSONObject) new JSONObject(response).getJSONObject("Item");
                    String title = (String) resObj.get("Title");
                    String encodedurl = "";
                    try {
                        encodedurl = URLEncoder.encode(title, "UTF-8");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    String path = "http://csci571-node.us-east-2.elasticbeanstalk.com/photoDetails?title="+encodedurl;
                    final View finalView = view;
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, path,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    generatePhotos(finalView,response);

                                }
                            }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            System.out.println("fail");
                            TextView noresults = (TextView) finalView.findViewById(R.id.noresults);
                            noresults.setVisibility(View.VISIBLE);
                        }
                    });
                    queue.add(stringRequest);
                }catch (Exception e) {
                    e.printStackTrace();
                }
                return view;
            }
            else
                if(position==3){
                    view = inflater.inflate(R.layout.recycle, container, false);
                    Spinner mySpinner2=(Spinner) view.findViewById(R.id.spinner2);
                    mySpinner2.setEnabled(false);
                    RequestQueue queue = Volley.newRequestQueue(view.getContext());
                    String path="http://csci571-node.us-east-2.elasticbeanstalk.com/similarDetails?itemId="+Global.selectedItemId;
                    final View finalView = view;
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, path,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    // Display the first 500 characters of the response string.
                                    generateSimilarItems(finalView,response);
                                    spinnerManipulation(finalView);
                                }
                            }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            System.out.println("fail");
                        }
                    });
                    queue.add(stringRequest);
                }

      return view;
    }

    public void spinnerManipulation(View view){
        Spinner mySpinner=(Spinner) view.findViewById(R.id.spinner1);
        Spinner mySpinner2=(Spinner) view.findViewById(R.id.spinner2);
        Global.spinner2=mySpinner2;
        mySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Object item = parent.getItemAtPosition(position);
                Global.spinner2.setEnabled(true);
                if(item.toString().equals("Name")){
                    sortByName(view);
                    Global.spinner1="Name";
                }
                else
                if(item.toString().equals("Price")){
                    sortByPrice(view);
                    Global.spinner1="Price";
                }
                else
                if(item.toString().equals("Days")){
                    sortByDays(view);
                    Global.spinner1="Days";
                }
                else
                if(item.toString().equals("Default")){
                    sortByDefault(view);
                    Global.spinner1="Default";
                }
            }
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        mySpinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Object item = parent.getItemAtPosition(position);
                if(Global.spinner1.equals("Name")){
                    sortByName(view);
                }
                else
                if(Global.spinner1.equals("Price")){
                    sortByPrice(view);
                }
                else
                if(Global.spinner1.equals("Days")){
                    sortByDays(view);
                }
                else
                if(Global.spinner1.equals("Default")){
                    sortByDefault(view);
                }
            }
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    public void sortByDefault(View view){
        itemList = Global.defaultList;
        SimilarItemAdapter adapter = new SimilarItemAdapter(view.getContext(), itemList);
        Global.spinner2.setEnabled(false);
        recyclerView.setAdapter(adapter);
    }

    public void sortByName(View view){
        Spinner mySpinner2=Global.spinner2;
        if(mySpinner2.getSelectedItem().equals("Ascending")){
            Collections.sort(itemList, new Comparator<SimilarItem>() {
                @Override
                public int compare(SimilarItem u1, SimilarItem u2) {
                    return u1.getTitle().compareTo(u2.getTitle());
                }
            });
        }
        else{
            Collections.sort(itemList, new Comparator<SimilarItem>() {
                @Override
                public int compare(SimilarItem u1, SimilarItem u2) {
                    return u2.getTitle().compareTo(u1.getTitle());
                }
            });
        }
        SimilarItemAdapter adapter = new SimilarItemAdapter(view.getContext(), itemList);
        recyclerView.setAdapter(adapter);
    }

    public void sortByPrice(View view){
        Spinner mySpinner2=Global.spinner2;
        if(mySpinner2.getSelectedItem().equals("Ascending")){
            Collections.sort(itemList, new Comparator<SimilarItem>() {
                @Override
                public int compare(SimilarItem u1, SimilarItem u2) {
                    if (u2.getPrice() > u1.getPrice()) {
                        return -1;
                    }
                    if (u2.getPrice() < u1.getPrice()) {
                        return 1;
                    }
                    return 0;
                }
            });
        }
        else{
            Collections.sort(itemList, new Comparator<SimilarItem>() {
                @Override
                public int compare(SimilarItem u1, SimilarItem u2) {
                    if (u1.getPrice() > u2.getPrice()) {
                        return -1;
                    }
                    if (u1.getPrice() < u2.getPrice()) {
                        return 1;
                    }
                    return 0;
                }
            });
        }
        SimilarItemAdapter adapter = new SimilarItemAdapter(view.getContext(), itemList);
        recyclerView.setAdapter(adapter);
    }

    public void sortByDays(View view){
        Spinner mySpinner2=Global.spinner2;
        if(mySpinner2.getSelectedItem().equals("Ascending")){
            Collections.sort(itemList, new Comparator<SimilarItem>() {
                @Override
                public int compare(SimilarItem u1, SimilarItem u2) {
                    if (u2.getDaysLeft() > u1.getDaysLeft()) {
                        return -1;
                    }
                    if (u2.getDaysLeft() < u1.getDaysLeft()) {
                        return 1;
                    }
                    return 0;
                }
            });
        }
        else{
            Collections.sort(itemList, new Comparator<SimilarItem>() {
                @Override
                public int compare(SimilarItem u1, SimilarItem u2) {
                    if (u1.getDaysLeft() > u2.getDaysLeft()) {
                        return -1;
                    }
                    if (u1.getDaysLeft() < u2.getDaysLeft()) {
                        return 1;
                    }
                    return 0;
                }
            });
        }
        SimilarItemAdapter adapter = new SimilarItemAdapter(view.getContext(), itemList);
        recyclerView.setAdapter(adapter);
    }


    public void generateSimilarItems(View view,String json) {
        itemList = new ArrayList<>();
        recyclerView = (RecyclerView) view.findViewById(R.id.recyclerSortedCardView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setVisibility(View.VISIBLE);
        TextView noresults = (TextView) view.findViewById(R.id.noresults);
        noresults.setVisibility(View.GONE);
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        try {
            JSONObject getSimilarItemsResponse = (JSONObject) new JSONObject(json).getJSONObject("getSimilarItemsResponse");
            JSONObject itemRecommendations=getSimilarItemsResponse.getJSONObject("itemRecommendations");
            if(itemRecommendations.has("item")){
                    JSONArray item=itemRecommendations.getJSONArray("item");
                    System.out.println(item.length());
                if(item.length()>0){
                    for(int i=0;i<item.length();i++){
                        String id="N/A";
                        String image="";
                        String title="N/A";
                        String daysLeft="N/A";
                        JSONObject shipping=null;
                        String condition="N/A";
                        JSONObject price =null;
                        String price_prop="0.00";
                        String ship="";
                        String itemUrl="";
                        JSONObject obj= (JSONObject) item.get(i);

                        if(obj.has("title"))
                            title= (String) obj.get("title");

                        if(obj.has("imageURL"))
                            image=(String) obj.get("imageURL");

                        if(obj.has("timeLeft")){
                            daysLeft=(String) obj.get("timeLeft").toString().substring(obj.get("timeLeft").toString().indexOf("P")+1,obj.get("timeLeft").toString().indexOf("D"));
                        }

                        if(obj.has("shippingCost")){
                            shipping=(JSONObject) obj.get("shippingCost");
                            ship= (String) shipping.get("__value__");
                            if(ship.equals("0.00")){
                                ship="Free Shipping";
                            }
                            else
                                ship=ship+" USD";
                        }

                        if(obj.has("buyItNowPrice")){
                            price=(JSONObject) obj.get("buyItNowPrice");
                            price_prop= (String) price.get("__value__").toString();
                        }

                        if(obj.has("viewItemURL")){
                            itemUrl=(String) obj.get("viewItemURL");
                        }
                        itemList.add(
                                new SimilarItem(image,title,ship,Integer.parseInt(daysLeft),Float.parseFloat(price_prop),itemUrl));

                    }
                    //creating recyclerview adapter
                    Global.defaultList=itemList;
                    SimilarItemAdapter adapter = new SimilarItemAdapter(view.getContext(), itemList);

                    //setting adapter to recyclerview
                    recyclerView.setAdapter(adapter);
                }
                else{
                    recyclerView.setVisibility(View.GONE);
                    noresults = (TextView) view.findViewById(R.id.noresults);
                    noresults.setVisibility(View.VISIBLE);
                }

            }
            else{
                recyclerView.setVisibility(View.GONE);
                noresults = (TextView) view.findViewById(R.id.noresults);
                noresults.setVisibility(View.VISIBLE);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void generatePhotos(View view,String json){
        try {
            TextView noresults = (TextView) view.findViewById(R.id.noresults);
            noresults.setVisibility(View.GONE);
            LinearLayout lLayout = (LinearLayout) view.findViewById(R.id.photos);
            if(new JSONObject(json).has("items")){
                JSONArray items = (JSONArray) new JSONObject(json).getJSONArray("items");
                if(items.length()>0){
                    for(int i=0;i<items.length();i++){
                        String link= (String) items.getJSONObject(i).get("link");
                        JSONObject image= (JSONObject) items.getJSONObject(i).getJSONObject("image");
                        int height= (int) image.get("height");
                        ImageView iv = new ImageView(view.getContext()); // Prepare textview object programmatically
                        iv.setId(i);
                        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
                        lp.setMargins(0, 0, 0, 20);
                        iv.setAdjustViewBounds(true);
                        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                        iv.setLayoutParams(lp);
                        lLayout.addView(iv);
                        Picasso.with(view.getContext()).load(link).resize(0, (int) (height*(view.getContext().getResources().getDisplayMetrics().density)+0.5f)).into(iv);
                    }
                }
            }
            else{
                noresults = (TextView) view.findViewById(R.id.noresults);
                noresults.setVisibility(View.VISIBLE);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }
}