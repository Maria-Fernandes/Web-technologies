package com.example.myapplication;

public class SimilarItem {
    private String image;
    private String title;
    private String shipping;
    private int daysLeft;
    private float price;
    private String itemUrl;


    public SimilarItem(String image,String title, String shipping,int daysLeft, float price,String itemUrl) {
        this.image = image;
        this.title = title;
        this.shipping = shipping;
        this.daysLeft=daysLeft;
        this.price = price;
        this.itemUrl=itemUrl;

    }

    public String getItemUrl(){
        return itemUrl;
    }

    public String getImage() {
        return image;
    }

    public String getTitle() {
        return title;
    }

    public String getShipping() {
        return shipping;
    }

    public int getDaysLeft() {
        return daysLeft;
    }

    public float getPrice() {
        return price;
    }


}


